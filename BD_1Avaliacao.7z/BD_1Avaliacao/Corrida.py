import Passageiro


class Corrida:
    def __init__(self, nota, distancia, valor, passageiro):
        self.nome = nota
        self.idade = distancia
        self.valor = valor
        self.passageiro = Passageiro
