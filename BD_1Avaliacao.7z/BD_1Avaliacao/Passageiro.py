class Passageiro:
    def __init__(self, nome, documento):
        self.nome = nome
        self.documento = documento
